/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-5.3.0-src/configure --prefix=/root/openwrt-gcc/gcc-5.3.0 --enable-languages=c,c++,go --target=mipsel-linux --disable-multilib --with-arch=mips32r2 --with-abi=32 --with-float=soft --sysconfdir=/root/buildroot-2015.11.1/output/host/etc --with-sysroot=/root/buildroot-2015.11.1/output/host/usr/mipsel-buildroot-linux-gnu/sysroot --with-build-time-tools=/root/buildroot-2015.11.1/output/host/usr/mipsel-buildroot-linux-gnu/bin --localstatedir=/root/buildroot-2015.11.1/output/host/var";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "32" }, { "arch", "mips32r2" }, { "float", "soft" }, { "llsc", "llsc" } };
